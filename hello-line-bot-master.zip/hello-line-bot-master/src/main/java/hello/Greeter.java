package hello;

/**
 * Package : hello
 * --
 * Description :
 * Author : jasonlin
 * Date : 2016/12/30
 */
public class Greeter {
    public String sayHello() {
        return "Hello, World!";
    }
}
